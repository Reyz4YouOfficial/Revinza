module.exports = {
  Token: "",
  owner: "7933193490",
};